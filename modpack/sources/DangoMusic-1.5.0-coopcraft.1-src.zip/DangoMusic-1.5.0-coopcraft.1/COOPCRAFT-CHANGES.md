# CoopCraft integration changes

This is a modified version of DangoMusic, not an upstream release.

- Upstream: https://github.com/Sorihiko/DangoMusic
- Base: v1.5.0, commit da696d0871fa348323782d7d299ba10df46e07db
- Change date: 2026-10-27
- Version: 1.5.0-coopcraft.1

Changes:

- Changed the three modern glow shader classes to use the existing `quad.vert` vertex shader instead of the missing `outline/base.vert`. The existing shader supplies the same `a_Pos` and `a_UV` attributes required by `GlShader` and `Imm`.
- Added the CoopCraft revision suffix to distinguish the modified build from the official release.

The intended target for this revision is Minecraft 1.21.1 Fabric. No player, account, networking, or music-service behavior is changed. Other Minecraft versions and loaders have not been validated for this revision.

DangoMusic remains licensed under GNU GPL-3.0. See `LICENSE` and the upstream source for copyright and license notices. No endorsement by the upstream author is implied.
